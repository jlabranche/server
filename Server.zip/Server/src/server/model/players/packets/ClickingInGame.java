package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;

/**
 * Clicking in game
 **/
public class ClickingInGame implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {

	}

}
