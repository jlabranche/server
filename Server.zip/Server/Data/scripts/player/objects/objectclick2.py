from server.util import ScriptManager

def objectClick2_2213(player, obId, obX, obY):
	player.getPA().openUpBank()
def objectClick2_11758(player, obId, obX, obY):
	player.getPA().openUpBank()