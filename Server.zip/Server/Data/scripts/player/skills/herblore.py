from server.util import ScriptManager
from server.model.players.skills import Herblore
#
# @author Lmctruck30
#

def itemClick_199(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 3, 249)
	
def itemClick_201(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 5, 251)
	
def itemClick_203(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 11, 253)

def itemClick_205(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 20, 255)

def itemClick_207(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 25, 257)

def itemClick_3049(player, itemId, itemSlot):	
	Herblore.idHerb(c, itemId, itemSlot, 30, 2998)
	
def itemClick_209(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 40, 259)

def itemClick_211(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 48, 261)

def itemClick_213(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 54, 263)

def itemClick_2485(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 59, 3000)

def itemClick_215(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 65, 265)

def itemClick_1531(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 67, 2481)

def itemClick_217(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 70, 267)

def itemClick_1525(player, itemId, itemSlot):
	Herblore.idHerb(player, itemId, itemSlot, 75, 269)

