from server.util import ScriptManager

def npcClick2_522(c, npcId):
	c.getShops().openShop(1)

def npcClick2_523(c, npcId):
	c.getShops().openShop(1)

def npcClick2_546(c, npcId):
	c.getShops().openShop(7)

def npcClick2_548(c, npcId):
	c.getShops().openShop(8)

def npcClick2_537(c, npcId):
	c.getShops().openShop(9)

def npcClick2_582(c, npcId):
	c.getShops().openShop(48)