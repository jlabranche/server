# Eating Functions
# Author: Lmctruck30
#

from server.util import ScriptManager

# heal, delay, itemId, itemSlot

# cake
def itemClick_1891(player, itemId, itemSlot):
	player.getPA().eatFood(4, 1600, itemId, itemSlot)
# cake 2/3
def itemClick_1893(player, itemId, itemSlot):
	player.getPA().eatFood(4, 1600, itemId, itemSlot)
# cake 1/3
def itemClick_1895(player, itemId, itemSlot):
	player.getPA().eatFood(4, 1600, itemId, itemSlot)
# Bread
def itemClick_2309(player, itemId, itemSlot):
	player.getPA().eatFood(2, 1600, itemId, itemSlot)
# C cake 1/3
def itemClick_1901(player, itemId, itemSlot):
	player.getPA().eatFood(5, 1600, itemId, itemSlot)
# Shrimp
def itemClick_315(player, itemId, itemSlot):
	player.getPA().eatFood(3, 1600, itemId, itemSlot)
# Mackerel
def itemClick_355(player, itemId, itemSlot):
	player.getPA().eatFood(6, 1600, itemId, itemSlot)
# Cod
def itemClick_339(player, itemId, itemSlot):
	player.getPA().eatFood(7, 1600, itemId, itemSlot)
# Trout
def itemClick_333(player, itemId, itemSlot):
	player.getPA().eatFood(7, 1600, itemId, itemSlot)
# Pike
def itemClick_351(player, itemId, itemSlot):
	player.getPA().eatFood(8, 1600, itemId, itemSlot)
# Salmon
def itemClick_329(player, itemId, itemSlot):
	player.getPA().eatFood(9, 1600, itemId, itemSlot)
# Tuna
def itemClick_361(player, itemId, itemSlot):
	player.getPA().eatFood(10, 1600, itemId, itemSlot)
# Lobster
def itemClick_379(player, itemId, itemSlot):
	player.getPA().eatFood(12, 1600, itemId, itemSlot)
# Bass
def itemClick_365(player, itemId, itemSlot):
	player.getPA().eatFood(13, 1600, itemId, itemSlot)
# Swordfish
def itemClick_373(player, itemId, itemSlot):
	player.getPA().eatFood(14, 1600, itemId, itemSlot)
# Shark
def itemClick_385(player, itemId, itemSlot):
	player.getPA().eatFood(20, 1600, itemId, itemSlot)
# Manta
def itemClick_391(player, itemId, itemSlot):
	player.getPA().eatFood(22, 1600, itemId, itemSlot)